"""Unit tests for src.preprocessing"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
from src.data_loader import generate_sample_dataset
from src.preprocessing import clean, encode_and_scale, split


def test_clean_removes_duplicates():
    df = generate_sample_dataset(50)
    dup = pd.concat([df, df.iloc[[0]]], ignore_index=True)
    cleaned = clean(dup)
    assert len(cleaned) == len(df)


def test_encode_and_scale_fit_produces_numeric_columns():
    df = clean(generate_sample_dataset(50))
    transformed = encode_and_scale(df, fit=True)
    for col in ["contract_type", "internet_service", "payment_method"]:
        assert pd.api.types.is_numeric_dtype(transformed[col])


def test_split_shapes_match():
    df = encode_and_scale(clean(generate_sample_dataset(100)), fit=True)
    X_train, X_test, y_train, y_test = split(df)
    assert len(X_train) + len(X_test) == 100
    assert len(X_train) == len(y_train)
    assert len(X_test) == len(y_test)


if __name__ == "__main__":
    test_clean_removes_duplicates()
    test_encode_and_scale_fit_produces_numeric_columns()
    test_split_shapes_match()
    print("All preprocessing tests passed.")
