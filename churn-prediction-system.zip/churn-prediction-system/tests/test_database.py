"""Unit tests for src.database -- exercises full CRUD on a temp SQLite file."""
import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import database

SAMPLE_RECORD = {
    "tenure_months": 12, "monthly_charges": 70.5, "total_charges": 846.0,
    "support_calls": 2, "contract_type": "Month-to-month",
    "internet_service": "Fiber optic", "payment_method": "Electronic check",
    "churn_prediction": 1, "churn_probability": 0.83,
}


def test_crud_cycle():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        database.init_db(path)
        rid = database.create_record(SAMPLE_RECORD, path)
        assert database.read_record(rid, path) is not None

        assert database.update_record(rid, {"support_calls": 5}, path)
        assert database.read_record(rid, path)["support_calls"] == 5

        assert database.delete_record(rid, path)
        assert database.read_record(rid, path) is None
    finally:
        os.remove(path)


if __name__ == "__main__":
    test_crud_cycle()
    print("All database tests passed.")
