"""Unit tests for src.model -- checks the model trains and beats a naive baseline."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data_loader import generate_sample_dataset
from src.preprocessing import clean, encode_and_scale, split
from src.model import ChurnModel


def test_model_trains_and_beats_baseline():
    df = encode_and_scale(clean(generate_sample_dataset(500)), fit=True)
    X_train, X_test, y_train, y_test = split(df)

    model = ChurnModel().train(X_train, y_train)
    metrics = model.evaluate(X_test, y_test)

    baseline_accuracy = max(y_test.mean(), 1 - y_test.mean())
    assert metrics["accuracy"] >= baseline_accuracy - 0.05, "Model should be close to or beat the naive baseline"
    assert 0.0 <= metrics["precision"] <= 1.0
    assert 0.0 <= metrics["recall"] <= 1.0


if __name__ == "__main__":
    test_model_trains_and_beats_baseline()
    print("All model tests passed.")
