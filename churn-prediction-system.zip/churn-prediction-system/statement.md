# Problem Statement

## Problem Statement

Subscription-based businesses (telecom, streaming, SaaS) lose significant
revenue when customers churn — cancel their subscription or switch to a
competitor. Acquiring a new customer typically costs far more than retaining
an existing one, so businesses need a way to identify customers who are
likely to churn *before* they leave, so retention offers can be targeted
effectively. Manually reviewing every customer's usage and billing history
does not scale as the customer base grows.

This project builds a machine learning system that ingests customer
account data (tenure, billing, service usage, support interactions),
trains a classification model to predict the likelihood that a given
customer will churn, and gives the business a simple interface to score
new customers and track churn trends over time.

## Scope of the Project

**In scope:**
- Ingesting and validating structured customer account data
- Cleaning and transforming the data for machine learning
- Training and evaluating a binary churn classification model
- Providing a CLI to score individual customers on demand
- Persisting every prediction with full CRUD support (create, view,
  update, delete records)
- Generating aggregate analytics: overall churn rate, churn rate by
  contract type, and spending patterns of churners vs. non-churners

**Out of scope (potential future work):**
- A web-based UI or REST API
- Real-time streaming ingestion from a live billing system
- Multi-user authentication and role-based access control
- Automated retraining/MLOps pipeline

## Target Users

- **Customer retention / marketing teams** at subscription-based
  businesses, who want a ranked list of at-risk customers to target
  with retention offers
- **Data analysts** who want quick churn analytics without writing
  ad-hoc SQL/Python each time
- **Students/evaluators** reviewing this project, who can run the full
  pipeline locally with no external dataset or paid service required

## High-Level Features

1. **Data ingestion & preprocessing** — loads customer data (or generates
   a realistic synthetic sample on first run), validates its schema,
   cleans it, and encodes/scales it for modelling
2. **Churn prediction** — a trained Random Forest classifier predicts
   whether a customer will churn, along with a churn probability score
3. **Persistent storage with CRUD** — every prediction is saved to a
   local SQLite database and can be viewed, updated, or deleted
4. **Analytics & reporting** — on-demand report summarising churn rate
   overall and broken down by contract type, plus spending comparisons
   between churners and non-churners
