"""
model.py
Functional Module 2 (part A): Model Training.

Wraps a scikit-learn RandomForestClassifier for churn classification, with
save/load helpers so training only has to happen once.
"""
import os
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

from src import config
from src.logger import get_logger

logger = get_logger(__name__)


class ChurnModel:
    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=200,
            max_depth=8,
            random_state=config.RANDOM_STATE,
            class_weight="balanced",
        )

    def train(self, X_train, y_train):
        logger.info("Training RandomForestClassifier on %d samples", len(X_train))
        self.model.fit(X_train, y_train)
        return self

    def evaluate(self, X_test, y_test) -> dict:
        preds = self.model.predict(X_test)
        metrics = {
            "accuracy": round(accuracy_score(y_test, preds), 4),
            "precision": round(precision_score(y_test, preds, zero_division=0), 4),
            "recall": round(recall_score(y_test, preds, zero_division=0), 4),
            "f1_score": round(f1_score(y_test, preds, zero_division=0), 4),
        }
        logger.info("Evaluation metrics: %s", metrics)
        return metrics

    def feature_importance(self, feature_names) -> dict:
        importances = self.model.feature_importances_
        return dict(sorted(zip(feature_names, importances), key=lambda kv: kv[1], reverse=True))

    def predict(self, X):
        preds = self.model.predict(X)
        probs = self.model.predict_proba(X)[:, 1]
        return preds, probs

    def save(self, path: str = config.MODEL_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump(self.model, path)
        logger.info("Saved trained model to %s", path)

    def load(self, path: str = config.MODEL_PATH):
        if not os.path.exists(path):
            raise FileNotFoundError(f"No trained model found at {path}. Train it first.")
        self.model = joblib.load(path)
        logger.info("Loaded trained model from %s", path)
        return self
