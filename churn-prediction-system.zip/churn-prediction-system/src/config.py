"""
config.py
Central configuration for the Churn Prediction & Analytics System.
Keeping configuration in one place supports maintainability (a required
non-functional requirement) since paths / constants are changed in a
single location rather than scattered across modules.
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATA_DIR = os.path.join(BASE_DIR, "data")
RAW_DATA_PATH = os.path.join(DATA_DIR, "sample_customers.csv")

MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, "churn_model.joblib")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.joblib")
ENCODER_PATH = os.path.join(MODEL_DIR, "encoders.joblib")

DB_PATH = os.path.join(BASE_DIR, "churn_system.db")

LOG_DIR = os.path.join(BASE_DIR, "logs")
LOG_PATH = os.path.join(LOG_DIR, "app.log")

TARGET_COLUMN = "churn"
CATEGORICAL_COLUMNS = ["contract_type", "internet_service", "payment_method"]
NUMERIC_COLUMNS = ["tenure_months", "monthly_charges", "total_charges", "support_calls"]

RANDOM_STATE = 42
TEST_SIZE = 0.2

for _d in (DATA_DIR, MODEL_DIR, LOG_DIR):
    os.makedirs(_d, exist_ok=True)
