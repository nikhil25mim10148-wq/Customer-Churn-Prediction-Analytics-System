"""
logger.py
Provides a single, consistently configured logger for the whole system.
Satisfies the "Logging / Monitoring" and "Error handling strategy"
non-functional requirements: every module logs through this instead of
using print(), so behaviour and failures can be traced after the fact.
"""
import logging
import os
from src import config


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    )

    os.makedirs(config.LOG_DIR, exist_ok=True)
    file_handler = logging.FileHandler(config.LOG_PATH)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger
