"""
data_loader.py
Functional Module 1 (part A): Data Ingestion.

Responsible for reading raw customer data from CSV, validating that the
expected columns are present, and generating a synthetic sample dataset
when none exists yet (useful for first-run / demo purposes).
"""
import os
import numpy as np
import pandas as pd

from src import config
from src.logger import get_logger

logger = get_logger(__name__)

REQUIRED_COLUMNS = (
    config.NUMERIC_COLUMNS + config.CATEGORICAL_COLUMNS + [config.TARGET_COLUMN]
)


class DataValidationError(Exception):
    """Raised when the input dataset does not match the expected schema."""


def generate_sample_dataset(n_rows: int = 500, seed: int = config.RANDOM_STATE) -> pd.DataFrame:
    """Creates a synthetic but realistic telecom-style churn dataset.

    This lets the project run end-to-end out of the box without requiring
    the user to source an external dataset first.
    """
    rng = np.random.default_rng(seed)

    tenure_months = rng.integers(0, 72, n_rows)
    monthly_charges = np.round(rng.uniform(20, 120, n_rows), 2)
    total_charges = np.round(monthly_charges * (tenure_months + 1) * rng.uniform(0.9, 1.0, n_rows), 2)
    support_calls = rng.poisson(1.5, n_rows)

    contract_type = rng.choice(["Month-to-month", "One year", "Two year"], n_rows, p=[0.55, 0.25, 0.20])
    internet_service = rng.choice(["DSL", "Fiber optic", "No"], n_rows, p=[0.35, 0.45, 0.20])
    payment_method = rng.choice(
        ["Electronic check", "Mailed check", "Bank transfer", "Credit card"], n_rows
    )

    # Churn probability increases with month-to-month contracts, high monthly
    # charges, and frequent support calls -- gives the model a real signal to learn.
    churn_score = (
        (contract_type == "Month-to-month") * 0.35
        + (monthly_charges > 80) * 0.2
        + (support_calls >= 3) * 0.25
        + (tenure_months < 12) * 0.2
        + rng.normal(0, 0.15, n_rows)
    )
    churn = (churn_score > 0.45).astype(int)

    df = pd.DataFrame(
        {
            "tenure_months": tenure_months,
            "monthly_charges": monthly_charges,
            "total_charges": total_charges,
            "support_calls": support_calls,
            "contract_type": contract_type,
            "internet_service": internet_service,
            "payment_method": payment_method,
            "churn": churn,
        }
    )
    logger.info("Generated synthetic sample dataset with %d rows", n_rows)
    return df


def load_dataset(path: str = config.RAW_DATA_PATH) -> pd.DataFrame:
    """Loads the dataset from disk, creating a sample one on first run."""
    if not os.path.exists(path):
        logger.warning("No dataset found at %s, generating a sample dataset", path)
        df = generate_sample_dataset()
        df.to_csv(path, index=False)
        return df

    try:
        df = pd.read_csv(path)
    except Exception as exc:  # noqa: BLE001 - deliberately broad, re-raised with context
        logger.error("Failed to read dataset at %s: %s", path, exc)
        raise DataValidationError(f"Could not read dataset: {exc}") from exc

    validate_schema(df)
    logger.info("Loaded dataset with %d rows from %s", len(df), path)
    return df


def validate_schema(df: pd.DataFrame) -> None:
    """Ensures the dataframe has the columns the rest of the pipeline expects."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise DataValidationError(f"Dataset is missing required columns: {missing}")
    if df.empty:
        raise DataValidationError("Dataset is empty")
