"""
predictor.py
Functional Module 2 (part B): Prediction / Classification.

Ties preprocessing + the trained model together to score new, unseen
customers, and persists each prediction via the database module.
"""
import pandas as pd

from src import config, database
from src.model import ChurnModel
from src.preprocessing import encode_and_scale
from src.logger import get_logger

logger = get_logger(__name__)


class PredictionError(Exception):
    """Raised when a prediction request is malformed or the model is unavailable."""


REQUIRED_FIELDS = config.NUMERIC_COLUMNS + config.CATEGORICAL_COLUMNS


def validate_input(customer: dict) -> None:
    missing = [f for f in REQUIRED_FIELDS if f not in customer]
    if missing:
        raise PredictionError(f"Missing required fields: {missing}")
    for col in config.NUMERIC_COLUMNS:
        try:
            float(customer[col])
        except (TypeError, ValueError):
            raise PredictionError(f"Field '{col}' must be numeric")


def predict_customer(customer: dict, persist: bool = True) -> dict:
    """Predicts churn for a single customer dict and optionally stores the result."""
    validate_input(customer)

    df = pd.DataFrame([customer])
    try:
        transformed = encode_and_scale(df, fit=False)
    except FileNotFoundError as exc:
        raise PredictionError("Model artefacts not found. Train the model first.") from exc

    model = ChurnModel()
    try:
        model.load()
    except FileNotFoundError as exc:
        raise PredictionError(str(exc)) from exc

    X = transformed[config.NUMERIC_COLUMNS + config.CATEGORICAL_COLUMNS]
    preds, probs = model.predict(X)

    result = {
        **{k: customer[k] for k in REQUIRED_FIELDS},
        "churn_prediction": int(preds[0]),
        "churn_probability": round(float(probs[0]), 4),
    }

    if persist:
        database.init_db()
        record_id = database.create_record(result)
        result["record_id"] = record_id

    logger.info("Predicted churn=%s (p=%.4f) for customer", result["churn_prediction"], result["churn_probability"])
    return result
