"""
report.py
Functional Module 3 (part B): Reporting & Analytics.

Aggregates stored prediction records into summary analytics: overall churn
rate, breakdown by contract type, and average churn probability -- the
"reporting/analytics" functional requirement for the project.
"""
import pandas as pd

from src import database
from src.logger import get_logger

logger = get_logger(__name__)


def build_analytics_report() -> dict:
    records = database.read_all_records()
    if not records:
        logger.warning("No prediction records available for reporting")
        return {"total_records": 0, "message": "No predictions stored yet."}

    df = pd.DataFrame(records)
    report = {
        "total_records": len(df),
        "predicted_churn_count": int(df["churn_prediction"].sum()),
        "predicted_churn_rate": round(df["churn_prediction"].mean(), 4),
        "average_churn_probability": round(df["churn_probability"].mean(), 4),
        "churn_rate_by_contract_type": (
            df.groupby("contract_type")["churn_prediction"].mean().round(4).to_dict()
        ),
        "average_monthly_charges_by_churn": (
            df.groupby("churn_prediction")["monthly_charges"].mean().round(2).to_dict()
        ),
    }
    logger.info("Generated analytics report over %d records", len(df))
    return report


def print_report(report: dict) -> None:
    if report.get("total_records", 0) == 0:
        print(report.get("message"))
        return
    print("\n--- Churn Analytics Report ---")
    print(f"Total records          : {report['total_records']}")
    print(f"Predicted churners     : {report['predicted_churn_count']}")
    print(f"Predicted churn rate   : {report['predicted_churn_rate'] * 100:.2f}%")
    print(f"Avg churn probability  : {report['average_churn_probability']:.4f}")
    print("Churn rate by contract type:")
    for k, v in report["churn_rate_by_contract_type"].items():
        print(f"  {k:<18}: {v * 100:.2f}%")
    print("Avg monthly charges (0=stay, 1=churn):")
    for k, v in report["average_monthly_charges_by_churn"].items():
        print(f"  {k}: {v}")
