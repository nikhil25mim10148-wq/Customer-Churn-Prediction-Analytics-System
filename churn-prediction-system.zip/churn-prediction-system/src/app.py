"""
app.py
Main entry point: a simple command-line interface tying together all
three functional modules (Data, Model/Prediction, Storage/Reporting).

Run with:  python -m src.app
"""
import sys
import pandas as pd

from src import config, database
from src.data_loader import load_dataset, DataValidationError
from src.preprocessing import clean, encode_and_scale, split
from src.model import ChurnModel
from src.predictor import predict_customer, PredictionError
from src.report import build_analytics_report, print_report
from src.logger import get_logger

logger = get_logger(__name__)

MENU = """
==== Customer Churn Prediction & Analytics System ====
1. Train / retrain model
2. Predict churn for a new customer
3. View analytics report
4. View all stored predictions (Read)
5. Update a stored prediction (Update)
6. Delete a stored prediction (Delete)
0. Exit
"""


def train_model():
    try:
        df = load_dataset()
        df = clean(df)
        df_transformed = encode_and_scale(df, fit=True)
        X_train, X_test, y_train, y_test = split(df_transformed)

        model = ChurnModel()
        model.train(X_train, y_train)
        metrics = model.evaluate(X_test, y_test)
        model.save()

        print("Model trained successfully.")
        print("Evaluation metrics:", metrics)
        importances = model.feature_importance(X_train.columns)
        print("Top features:", list(importances.items())[:3])
    except DataValidationError as exc:
        print(f"[ERROR] Dataset problem: {exc}")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Unexpected error during training")
        print(f"[ERROR] Training failed: {exc}")


def predict_new_customer():
    print("Enter customer details:")
    try:
        customer = {
            "tenure_months": input("  Tenure (months): "),
            "monthly_charges": input("  Monthly charges: "),
            "total_charges": input("  Total charges: "),
            "support_calls": input("  Support calls: "),
            "contract_type": input("  Contract type [Month-to-month/One year/Two year]: "),
            "internet_service": input("  Internet service [DSL/Fiber optic/No]: "),
            "payment_method": input("  Payment method: "),
        }
        result = predict_customer(customer)
        label = "LIKELY TO CHURN" if result["churn_prediction"] == 1 else "LIKELY TO STAY"
        print(f"\nPrediction: {label} (probability={result['churn_probability']})")
        print(f"Saved as record id={result['record_id']}")
    except PredictionError as exc:
        print(f"[ERROR] {exc}")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Unexpected error during prediction")
        print(f"[ERROR] Prediction failed: {exc}")


def view_report():
    report = build_analytics_report()
    print_report(report)


def view_records():
    records = database.read_all_records()
    if not records:
        print("No records stored yet.")
        return
    df = pd.DataFrame(records)
    print(df.to_string(index=False))


def update_record():
    try:
        record_id = int(input("Record id to update: "))
        if not database.read_record(record_id):
            print("No such record.")
            return
        new_calls = input("New support_calls value (blank to skip): ").strip()
        fields = {}
        if new_calls:
            fields["support_calls"] = int(new_calls)
        ok = database.update_record(record_id, fields)
        print("Updated." if ok else "Nothing updated.")
    except ValueError:
        print("[ERROR] Please enter a valid integer id/value.")


def delete_record():
    try:
        record_id = int(input("Record id to delete: "))
        ok = database.delete_record(record_id)
        print("Deleted." if ok else "No such record.")
    except ValueError:
        print("[ERROR] Please enter a valid integer id.")


def main():
    database.init_db()
    actions = {
        "1": train_model,
        "2": predict_new_customer,
        "3": view_report,
        "4": view_records,
        "5": update_record,
        "6": delete_record,
    }
    while True:
        print(MENU)
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye.")
            sys.exit(0)
        action = actions.get(choice)
        if action:
            action()
        else:
            print("Invalid option, try again.")


if __name__ == "__main__":
    main()
