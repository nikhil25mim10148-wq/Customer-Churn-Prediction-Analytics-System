"""
preprocessing.py
Functional Module 1 (part B): Data Processing.

Handles cleaning, encoding of categorical variables, scaling of numeric
variables, and the train/test split used by the modelling module.
"""
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

from src import config
from src.logger import get_logger

logger = get_logger(__name__)


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop exact duplicates, fill missing numerics with median."""
    before = len(df)
    df = df.drop_duplicates().copy()
    for col in config.NUMERIC_COLUMNS:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].median())
    logger.info("Cleaning removed %d duplicate rows", before - len(df))
    return df


def encode_and_scale(df: pd.DataFrame, fit: bool = True):
    """Encodes categorical columns and scales numeric columns.

    When fit=True, new encoders/scaler are fit and persisted to disk.
    When fit=False, previously saved encoders/scaler are loaded and reused
    -- this is what happens at prediction time so new data is transformed
    exactly the same way the training data was.
    """
    df = df.copy()

    if fit:
        encoders = {}
        for col in config.CATEGORICAL_COLUMNS:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            encoders[col] = le
        joblib.dump(encoders, config.ENCODER_PATH)

        scaler = StandardScaler()
        df[config.NUMERIC_COLUMNS] = scaler.fit_transform(df[config.NUMERIC_COLUMNS])
        joblib.dump(scaler, config.SCALER_PATH)
        logger.info("Fitted and saved encoders + scaler")
    else:
        encoders = joblib.load(config.ENCODER_PATH)
        scaler = joblib.load(config.SCALER_PATH)
        for col in config.CATEGORICAL_COLUMNS:
            le = encoders[col]
            df[col] = df[col].astype(str).map(
                lambda v, le=le: le.transform([v])[0] if v in le.classes_ else -1
            )
        df[config.NUMERIC_COLUMNS] = scaler.transform(df[config.NUMERIC_COLUMNS])
        logger.info("Applied saved encoders + scaler to new data")

    return df


def split(df: pd.DataFrame):
    X = df[config.NUMERIC_COLUMNS + config.CATEGORICAL_COLUMNS]
    y = df[config.TARGET_COLUMN]
    return train_test_split(
        X, y, test_size=config.TEST_SIZE, random_state=config.RANDOM_STATE, stratify=y
    )
