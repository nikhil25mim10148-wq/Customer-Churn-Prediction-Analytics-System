"""
database.py
Storage module: SQLite persistence layer providing full CRUD operations
over customer prediction records (Functional Module 3, part A).

Using parameterised queries throughout protects against SQL injection,
which is one of the Security non-functional requirements for this project.
"""
import sqlite3
from contextlib import contextmanager
from datetime import datetime

from src import config
from src.logger import get_logger

logger = get_logger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenure_months INTEGER NOT NULL,
    monthly_charges REAL NOT NULL,
    total_charges REAL NOT NULL,
    support_calls INTEGER NOT NULL,
    contract_type TEXT NOT NULL,
    internet_service TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    churn_prediction INTEGER NOT NULL,
    churn_probability REAL NOT NULL,
    created_at TEXT NOT NULL
);
"""


@contextmanager
def get_connection(db_path: str = config.DB_PATH):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(db_path: str = config.DB_PATH) -> None:
    with get_connection(db_path) as conn:
        conn.execute(SCHEMA)
    logger.info("Database initialised at %s", db_path)


def create_record(record: dict, db_path: str = config.DB_PATH) -> int:
    with get_connection(db_path) as conn:
        cur = conn.execute(
            """INSERT INTO predictions
               (tenure_months, monthly_charges, total_charges, support_calls,
                contract_type, internet_service, payment_method,
                churn_prediction, churn_probability, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                record["tenure_months"], record["monthly_charges"],
                record["total_charges"], record["support_calls"],
                record["contract_type"], record["internet_service"],
                record["payment_method"], record["churn_prediction"],
                record["churn_probability"], datetime.utcnow().isoformat(),
            ),
        )
        logger.info("Inserted prediction record id=%d", cur.lastrowid)
        return cur.lastrowid


def read_all_records(db_path: str = config.DB_PATH) -> list:
    with get_connection(db_path) as conn:
        rows = conn.execute("SELECT * FROM predictions ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]


def read_record(record_id: int, db_path: str = config.DB_PATH) -> dict | None:
    with get_connection(db_path) as conn:
        row = conn.execute("SELECT * FROM predictions WHERE id = ?", (record_id,)).fetchone()
        return dict(row) if row else None


def update_record(record_id: int, fields: dict, db_path: str = config.DB_PATH) -> bool:
    if not fields:
        return False
    columns = ", ".join(f"{k} = ?" for k in fields)
    values = list(fields.values()) + [record_id]
    with get_connection(db_path) as conn:
        cur = conn.execute(f"UPDATE predictions SET {columns} WHERE id = ?", values)
        logger.info("Updated record id=%d (%d row(s) affected)", record_id, cur.rowcount)
        return cur.rowcount > 0


def delete_record(record_id: int, db_path: str = config.DB_PATH) -> bool:
    with get_connection(db_path) as conn:
        cur = conn.execute("DELETE FROM predictions WHERE id = ?", (record_id,))
        logger.info("Deleted record id=%d (%d row(s) affected)", record_id, cur.rowcount)
        return cur.rowcount > 0
